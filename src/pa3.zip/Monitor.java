/**
 * Class Monitor
 * To synchronize dining philosophers.
 *
 * @author Serguei A. Mokhov, mokhov@cs.concordia.ca
 */
public class Monitor
{
	/*
	 * ------------
	 * Data members
	 * ------------
	 */
	public enum states {Eating, Hungry, Thinking, Talking};
	states[] philStates ;
	int numOfPhils;
	boolean talking = false;
	//int priorityCounter = 1;
	
	
	
	

	/**
	 * Constructor
	 */
	public Monitor(int piNumberOfPhilosophers)
	{
		// TODO: set appropriate number of chopsticks based on the # of philosophers
		this.numOfPhils = piNumberOfPhilosophers;
		philStates = new states[piNumberOfPhilosophers];
		
		for(int i = 0; i< piNumberOfPhilosophers; i++) {
			philStates[i] = states.Thinking;
		}
		talking = false;
		
	}

	/*
	 * -------------------------------
	 * User-defined monitor procedures
	 * -------------------------------
	 */

	/**
	 * Grants request (returns) to eat when both chopsticks/forks are available.
	 * Else forces the philosopher to wait()
	 */
	public synchronized void pickUp(final int piTID)
	{
		try {
		
			int index = piTID-1;
		
			while(philStates[Math.abs((index-1))% numOfPhils] == states.Eating || 
					philStates [(index+1)% numOfPhils] == states.Eating) {
					philStates[index] = states.Hungry;
				
						wait();
					
			
		}
			
			
			philStates[index]= states.Eating;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ...
	}
	public synchronized boolean highestPriority(final int piTID) {
		boolean highest = true;
		for (int i =0; i< numOfPhils;i++) {
			if(philStates[i] == states.Hungry && (i+1)<piTID) {
				highest = false;
			}
		}
		return highest;
	}

	/**
	 * When a given philosopher's done eating, they put the chopstiks/forks down
	 * and let others know they are available.
	 */
	public synchronized void putDown(final int piTID)
	{
		philStates[piTID-1] = states.Thinking;
		
		
		notifyAll();
		
	}

	/**
	 * Only one philopher at a time is allowed to philosophy
	 * (while she is not eating).
	 */
	public synchronized void requestTalk(final int piTID)
	{
		try {
			while(talking)
				wait();
				philStates[piTID-1] = states.Talking;
				talking = true;
		
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * When one philosopher is done talking stuff, others
	 * can feel free to start talking.
	 */
	public synchronized void endTalk(final int piTID)
	{
		philStates[piTID-1] = states.Thinking;
		talking = false;
		notifyAll();
		// ...
	}
}

// EOF
